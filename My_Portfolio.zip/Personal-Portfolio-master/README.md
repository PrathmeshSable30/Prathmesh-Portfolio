## Personal Portfolio

This is my first professional website using HTML and CSS, developed with lots of ❤️ and ☕.
Hope you like it!

## Final Project

![WebSite Frame](https://user-images.githubusercontent.com/61896414/155162248-ddca6e02-eee4-4cdf-9b17-409619c367a6.jpg)

## Designed with Figma

Link to the project: https://www.figma.com/file/V5633KPK0E5koiD2gboYbv/Personal-Web?node-id=0%3A1
